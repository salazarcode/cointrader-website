<a href="@permalink">
    <div class="card has-shadow-overlay has-background-dark">
        <div class="is-overlay is-opaque is-parallax-contain is-15" style="background-image: url(@thumbnail('full', false)); background-size: cover"></div>
        <div class="card-content">
            <h2 class="title is-2 has-text-white has-text-weight-light has-margin-top-145 has-margin-bottom-35">
              <span class="icon is-large"> <i data-feather="map-pin"></i></span> <span>@title</span> 
            </h2>
        </div>
    </div>
</a>
