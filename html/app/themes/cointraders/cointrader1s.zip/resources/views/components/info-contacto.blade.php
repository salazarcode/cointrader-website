<a href="mailto:info@intraders.com">
    <span>Email:</span><strong> Info@intraders.com</strong>
</a>
<a href="tel:57 313 5745204">
    <span>Whatsapp:</span><strong> +57 313 5745204</strong>
</a>
<a href="#">
    <span>Telegram:</span><strong> @Soporteintraders</strong>
</a>