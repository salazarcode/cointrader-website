
<div class="hero is-fullheight is-relative" style="padding-left: 80px;">
    <div class="hero-body has-padding-bottom-100">
        <div class="container" data-aos="fade-up">
            <h1 class="title is-1" style="letter-spacing: 6px;">
                <span class="has-text-primary font-w is-400">DINERO </span></br>
                <span class="has-magin-bottom-10 is-inline-block has-text-primary font-w is-700">EFICIENTE</span></br>
                <span class="has-text-white font-w is-400">ECONOMÍA </span></br>
                <span class="has-text-white font-w is-700">MODERNA</span>
            </h1>
        </div>
    </div>
</div>