<div class="page-header is-flex align-items-flex-end has-background-dark is-clipped" style="min-height: 50vh;">
  <div class="is-parallax-cover is-full-width is-full-height" style="mix-blend-mode:color-burn;left:0;position: absolute;background: url('@thumbnail('full', false)')"></div>
  <div class="container">
    <h1 class="title is-1 has-margin-bottom-40 has-text-white">{!! $title !!}</h1>
  </div>
</div>
