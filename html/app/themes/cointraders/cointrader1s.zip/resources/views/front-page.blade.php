@extends('layouts.app')

@section('content')
@include('partials.hero')
@include('partials.tarjetas')
@endsection